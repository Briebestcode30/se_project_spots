# Spots

An image sharing site.

## Description

gives user acces to view and make profiles

## Tech Stack

.html
.css
.Responsive Design

## Deployment

This webpage is deployed to GitHub Pages

- [Deployment Link](https://briebestcode30.github.io/se_project_spots/)
